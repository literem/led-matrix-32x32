#include "Arduino.h"
#include "command.h"

u8 _cmd_buf[10];
u8 _cmd_buf_len=0;

//起始位1 起始位2 命令标志位 命令长度位 命令位1 命令位2 数据位H 数据位L 结束位1 结束位2
//  0       1       2         3       4     5       6     7       8     9
/**
 * 检查命令是否正确
 */
u8 check_command(u8* buf)
{
  if(buf[0]!=0xff || buf[1]!=0xff) return CMD_ERROR;
  if(buf[8]!=0xff || buf[9]!=0xff) return CMD_ERROR;
  if(buf[2]!=CMD_FLAG || buf[3]!=CMD_LEN) return CMD_ERROR;
  return buf[4];
}

u16 get_command_data()
{
  return (_cmd_buf[6]<<8) + _cmd_buf[7];
}

/**
 * 接收并判断命令是否正确
 */
u8 receive_handle_command()
{
  while(Serial.available() > 0)
  {
    _cmd_buf[_cmd_buf_len] = Serial.read();
    _cmd_buf_len++;
    if(_cmd_buf_len == 10) 
    {
      _cmd_buf_len = 0;
      return check_command(_cmd_buf);
    }
  }
  return CMD_ERROR;
}
