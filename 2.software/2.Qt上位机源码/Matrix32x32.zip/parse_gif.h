#ifndef PARSEGIF_H
#define PARSEGIF_H

#include <QtGlobal>
#include <QImage>

#define PARSE_PATH_NULL     0
#define PARSE_PATH_EMPTY    1
#define PARSE_PATH_ERROR    2
#define PARSE_SUCCESS       3

class ParseGIF
{
public:
    ParseGIF(){}



public:
    int parseGIF(QString dirPath);
    quint8* parseOneImage(QString imgPath,int value);
    quint8* parseOneImage(QImage &img,int value);
    bool saveBinArray(QList<quint8*> *list,QString filePath);
    void setReverse(bool reverse);
protected:
    quint8* imageToBinArray(QImage &img,int value);
    bool isReverse = false;
};

#endif // PARSEGIF_H
