#include "matrix_command.h"
#include "page3gif.h"
#include "ui_page3gif.h"

#include <QBitmap>
#include <QFileDialog>
#include <QMessageBox>
#include <QThread>
#include <QDebug>

QString customPath = "";
QString blueButtonStyle = "background:rgb(0, 170, 255);border-radius:10px;color:white;";
QString redButtonStyle = "background:rgb(255, 0, 0);border-radius:10px;color:white;";
QString greenButtonStyle = "background:rgb(0, 255, 0);border-radius:10px;color:white;";
bool badAppleStatus = false;
bool isPlayBadApple = false;

page3GIF::page3GIF(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::page3GIF)
{
    ui->setupUi(this);
    ui->button_stop->setVisible(false);
}

page3GIF::~page3GIF()
{
    delete ui;
}

//槽函数，更新播放进度
void page3GIF::setProgressBarValue(int value)
{
    ui->progressBar->setValue(value);
}

//加载bin文件
QList<SendDataArray *> *page3GIF::loadGifBin()
{
    // 获取文件路径
    QString filePath = getGifBinPath();
    if(filePath == nullptr || filePath.isEmpty())
    {
        QMessageBox::warning(this,"提示","请选择要播放的内容");
        return nullptr;
    }
    QFile file(filePath);// 创建文件对象
    if (!file.open(QFile::ReadOnly)) return nullptr;// 以只读方式打开文件
    QDataStream stream(&file);// 创建数据流
    char buf[128];
    QList<SendDataArray*> *list = new QList<SendDataArray*>();

    // 循环读取数据
    while (!stream.atEnd())
    {
        // 读取数据到缓冲区 buf 中，最多读取 1024 个字节，返回实际读取的字节数；
        int len = stream.readRawData(buf, 128);
        if(len == 128)
        {
            SendDataArray *sda = new SendDataArray(128);
            sda->copyToArray(buf,128);
            list->append(sda);
        }
    }
    file.close(); // 关闭文件
    return list;
}

void page3GIF::loadDefaultPathBinArray()
{
    QString binArrayPath = QDir::currentPath() + "/binArray";
    QDir dir = QDir(binArrayPath);
    if(!dir.exists()) return;
    QStringList filters;
    filters << QString("*.bin");
    QFileInfoList fileList = dir.entryInfoList(filters,QDir::Files);

    ui->comboBox->clear();
    for (int i = 0; i < fileList.size(); ++i)
    {
        ui->comboBox->addItem(fileList.at(i).fileName());
    }
}

//获取选择的bin文件路径
QString page3GIF::getGifBinPath()
{
    if(ui->rb_badapple_3265->isChecked())
    {
        return ":/bin/badApple-3265.bin";
    }
    else if(ui->rb_badapple_6531->isChecked())
    {
        return ":/bin/badApple-6531.bin";
    }
    else if(ui->rb_heartbeat->isChecked())
    {
        return ":/bin/heartbeat.bin";
    }
    else if(ui->rb_default_path->isChecked())
    {
        return getComboBoxBinPath();
    }
    else if(ui->rb_custom->isChecked())
    {
        return customPath;
    }
    else
    {
        return nullptr;
    }
}

QString page3GIF::getComboBoxBinPath()
{
    if(ui->comboBox->currentIndex() == -1) return nullptr;
    QString fileName = ui->comboBox->currentText();
    if(fileName.isEmpty()) return nullptr;
    return QDir::currentPath() + "/binArray/" + fileName;
}

//播放-暂停
void page3GIF::on_button_play_clicked()
{
    if(isPlayBadApple == false)
    {
        QList<SendDataArray *> *list = loadGifBin();
        if(list == nullptr)
        {
            QMessageBox::warning(this,"警告","文件打开失败");
            return;
        }
        if(list->size() <= 1)
        {
            QMessageBox::warning(this,"警告","当前选择的帧只有一帧，无法进行播放");
            qDeleteAll(*list);
            list->clear();
            return;
        }
        quint16 size = list->size();
        quint8* cmd = MatrixCommand::createPlayGifCmd(size);

        ui->progressBar->setMaximum(size);
        ui->progressBar->setValue(0);
        emit sendOneData(cmd,10,SEND_TO_SERIAL);
        QThread::msleep(100);
        emit sendListData(list);
        isPlayBadApple = true;
        badAppleStatus = true;
        delete[] cmd;
        ui->button_play->setStyleSheet(greenButtonStyle);
        ui->button_play->setText("暂停");
        ui->button_stop->setVisible(true);
        return;
    }

    if(badAppleStatus == false)
    {
        badAppleStatus = true;
        ui->button_play->setStyleSheet(greenButtonStyle);
        ui->button_play->setText("暂停");
        emit setThreadStatus(SEND_THREAD_RUN);
    }
    else
    {
        badAppleStatus = false;
        ui->button_play->setStyleSheet(blueButtonStyle);
        ui->button_play->setText("继续");
        emit setThreadStatus(SEND_THREAD_PAUSE);
    }
}

//停止
void page3GIF::on_button_stop_clicked()
{
    badAppleStatus = false;
    isPlayBadApple = false;
    ui->button_play->setStyleSheet(blueButtonStyle);
    ui->button_play->setText("开始播放");
    quint8* cmd = MatrixCommand::createExitGifCmd();
    emit sendOneData(cmd,10,SEND_TO_THREAD);
    emit setThreadStatus(SEND_THREAD_STOP);
    ui->button_stop->setVisible(false);
}

//拖动条数值改变
void page3GIF::on_horizontalSlider_valueChanged(int value)
{
    speedGIF = value;
    QString text = QString::number(value) + QString("/255");
    ui->label_speed->setText(text);
}

//设置速度
void page3GIF::on_button_speed_clicked()
{
    if(speedGIF < 1)
    {
        speedGIF = 1;
        ui->progressBar->setValue(speedGIF);
        ui->label_speed->setText("1/255");
    }
    quint8* cmd = MatrixCommand::createSpeedGifCmd(speedGIF);
    emit sendOneData(cmd,10,SEND_TO_THREAD);
}

//自选二进制数组Bin文件
void page3GIF::on_rb_custom_clicked()
{
    QString filename = QFileDialog::getOpenFileName(this,"选择二进制数组Bin文件",QDir::currentPath(),"Bin (*.bin)");
    if(filename.isEmpty())
    {
        //没有选择路径时取消选中，如果只调用setChecked函数是不能取消选中的
        ui->rb_custom->setAutoExclusive(false);
        ui->rb_custom->setChecked(false);
        ui->rb_custom->setAutoExclusive(true);
    }
    else
    {
        customPath = filename;
    }
}

void page3GIF::on_rb_default_path_clicked()
{
    //刷新列表
    loadDefaultPathBinArray();

    //判断comboBox是否有bin文件
    if(ui->comboBox->count() == 0)
    {
        QMessageBox::warning(this,"提示","默认路径下没有Bin文件");
        ui->rb_default_path->setAutoExclusive(false);
        ui->rb_default_path->setChecked(false);
        ui->rb_default_path->setAutoExclusive(true);
    }
}

