#include "Arduino.h"
#include "scanning.h"
#include "display_gif.h"
#include "command.h"
#include <string.h>

#define GET_GIF_DAT() ((_gif_buf[6]<<8) + _gif_buf[7])

/********* 相关变量 ************/
u16 _gif_count;
u16 _gif_index;
u8 _gif_status;
u8 _gif_speed = 15;
u8 _gif_speed_i;
u8 _gif_buf[128];
u8 _request_buf[10] = {0xFF,0xEF,0x0A,0,0,0,0,0xFF,0xFF,0xFF};
u8 _buf_len;
u8 overTime;
u8 isReceive;

void copy_buf_data()
{
  memcpy(&matrix_buf[0][0],_gif_buf,128);
  _buf_len = 0;
  isReceive = 0;
  while(Serial.read() >= 0){}
}

//起始位1 起始位2 命令标志位 命令长度位 命令位1 命令位2 数据位H 数据位L 结束位1 结束位2
//  0       1       2         3       4     5       6     7       8     9
void handle_gif_command()
{
  u8 cmd = check_command(_gif_buf);
  switch(cmd)
  {
    case GIF_CMD_SPEED: _gif_speed = GET_GIF_DAT();break;
    case GIF_CMD_STOP: _gif_status = GIF_STOP;break;
    case CMD_ERROR:return;
    default:return;
  }
  _buf_len = 0;
  overTime=245;
  while(Serial.read() >= 0){}
}

//起始位1 命令标志位 命令长度位 当前长度位H 当前长度位L 总长度位H 总长度位L 结束位1 
//  0       1       2         3       4           5       6         7      
void request_gif_frame()
{
  if(_gif_index == _gif_count) _gif_index = 0;
  _request_buf[3] = _gif_index >> 8;
  _request_buf[4] = _gif_index & 0xff;
  Serial.write(_request_buf,10);
}

void display_gif_init(u16 gif_len)
{
  memset(&matrix_buf[0][0],0xff,128);
  _gif_count = gif_len;
  _gif_index = 0;
  _gif_status = GIF_RUN;

  _request_buf[5] = gif_len >> 8;
  _request_buf[6] = gif_len & 0xff;
}

void display_gif()
{
  delay(500);
  while(_gif_status == GIF_RUN)
  {
    //请求下一帧
    request_gif_frame();
    _gif_index++;
    
    for(isReceive=1,overTime=0;isReceive&&_gif_status==GIF_RUN;overTime++)
    {
      //等待接收数据的过程中刷新帧
      for(_gif_speed_i = 0; _gif_speed_i < _gif_speed; _gif_speed_i++) scan_one_frame();

      //如果接收数据超时了，重新请求当前帧
      if(overTime == 255)
      {
        _buf_len = overTime = 0;
        request_gif_frame();
      }

      //接收数据帧
      while(Serial.available() > 0)
      {
        _gif_buf[_buf_len++] = Serial.read();
        
        //判断是否接收了128个字节
        if(_buf_len == 128) {copy_buf_data();break;}

        //判断10字节命令，处理完命令后，设置短暂的即将要超时的时间，以便于重新请求帧数据
        if(_buf_len == 10) handle_gif_command();
      }
    }
  }
}
