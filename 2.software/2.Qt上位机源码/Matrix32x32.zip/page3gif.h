#ifndef PAGE3GIF_H
#define PAGE3GIF_H

#include <QWidget>
#include <QImage>

#include "send_data_array.h"

#include <QList>

namespace Ui {
class page3GIF;
}

class page3GIF : public QWidget
{
    Q_OBJECT

public:
    explicit page3GIF(QWidget *parent = nullptr);
    ~page3GIF();

    void setProgressBarValue(int value);

Q_SIGNALS:
    void sendOneData(quint8* dat,int len,int flag);
    void sendListData(QList<SendDataArray*> *list);
    void setThreadStatus(int status);

private slots:
    void on_button_stop_clicked();

    void on_button_play_clicked();

    void on_horizontalSlider_valueChanged(int value);

    void on_button_speed_clicked();

    void on_rb_custom_clicked();

    void on_rb_default_path_clicked();

private:
    QList<SendDataArray*> * loadGifBin();
    void loadDefaultPathBinArray(void);
    QString getGifBinPath();
    QString getComboBoxBinPath();

private:
    Ui::page3GIF *ui;
    quint8 speedGIF = 0;
};

#endif // PAGE3GIF_H
