#include "mainwindow.h"
#include "page3gif.h"
#include "page4tools.h"
#include "ui_mainwindow.h"
#include <QDebug>

#include <QtSerialPort/QSerialPort>

#include <Page1Serial.h>
#include <Page2Image.h>

int currentIndex=0;

QString buttonSelectStyle = "background-color:rgb(0, 170, 255);border: none;color: #FFF;font-size: 16px;";
QString buttonUnselectStyle  = "background-color:rgb(185, 185, 185);border: none;color: #FFF;font-size: 16px;";

Page1Serial *page1Serial;
Page2Image *page2Image;
page3GIF* page3gif;
Page4Tools* page4tools;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    page1Serial = new Page1Serial(this);
    page2Image = new Page2Image(this);
    page3gif = new page3GIF(this);
    page4tools = new Page4Tools(this);

    //添加页面
    ui->stackedWidget->addWidget(page1Serial);
    ui->stackedWidget->addWidget(page2Image);
    ui->stackedWidget->addWidget(page3gif);
    ui->stackedWidget->addWidget(page4tools);

    //显示page1页面作为主页
    ui->stackedWidget->setCurrentWidget(page1Serial);

    //左边按钮点击的槽函数连接
    connect(ui->serialButton, &QPushButton::clicked, this, &MainWindow::SwitchToSerialDialog);
    connect(ui->staticButton, &QPushButton::clicked, this, &MainWindow::SwitchToImageDialog);
    connect(ui->gifButton, &QPushButton::clicked, this, &MainWindow::SwitchToGIFDialog);
    connect(ui->toolsButton, &QPushButton::clicked, this, &MainWindow::SwitchToToolsDialog);

    //page2绑定的槽函数
    //connect(page2Image,&Page2Image::sendSerialData,  page1Serial,&Page1Serial::sendOneData);

    //page3绑定的槽函数
    connect(page3gif,&page3GIF::sendListData,  page1Serial,&Page1Serial::sendListData);
    connect(page3gif,&page3GIF::sendOneData,  page1Serial,&Page1Serial::sendOneData);
    connect(page3gif,&page3GIF::setThreadStatus,  page1Serial,&Page1Serial::setThreadStatus);

    //page1发送数据到page3的槽函数
    connect(page1Serial,&Page1Serial::updateProgress,  page3gif,&page3GIF::setProgressBarValue);
}

MainWindow::~MainWindow()
{
    delete page3gif;
    delete page4tools;
    delete page2Image;
    delete page1Serial;
    delete ui;
}

void MainWindow::hideAllDialog()
{
    ui->serialButton->setStyleSheet(buttonUnselectStyle);
    ui->staticButton->setStyleSheet(buttonUnselectStyle);
    ui->gifButton->setStyleSheet(buttonUnselectStyle);
    ui->toolsButton->setStyleSheet(buttonUnselectStyle);
}

void MainWindow::SwitchToSerialDialog()
{
    if(currentIndex == 0) return;
    hideAllDialog();
    ui->serialButton->setStyleSheet(buttonSelectStyle);
    ui->stackedWidget->setCurrentWidget(page1Serial);
    currentIndex = 0;
}

void MainWindow::SwitchToImageDialog()
{
    if(currentIndex == 1) return;
    hideAllDialog();
    ui->staticButton->setStyleSheet(buttonSelectStyle);
    ui->stackedWidget->setCurrentWidget(page2Image);
    currentIndex = 1;
}

void MainWindow::SwitchToGIFDialog()
{
    if(currentIndex == 2) return;
    hideAllDialog();
    ui->gifButton->setStyleSheet(buttonSelectStyle);
    ui->stackedWidget->setCurrentWidget(page3gif);
    currentIndex = 2;
}

void MainWindow::SwitchToToolsDialog()
{
    if(currentIndex == 3) return;
    hideAllDialog();
    ui->toolsButton->setStyleSheet(buttonSelectStyle);
    ui->stackedWidget->setCurrentWidget(page4tools);
    currentIndex = 3;
}


