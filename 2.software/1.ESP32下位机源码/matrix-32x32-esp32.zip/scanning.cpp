#include "Arduino.h"
#include "scanning.h"
#include "platform_esp32.h"
#include <string.h>

u8 matrix_buf[32][4];

#define HC138Disable()  OE1_LOW();OE2_LOW();OE3_LOW();OE4_LOW()

//74HC138行扫描,范围：0 - MaxRow
void scanning_row(u8 row)
{
    if( row       & 0x01) A1_HIGH(); else A1_LOW();
    if((row >> 1) & 0x01) A2_HIGH(); else A2_LOW();
    if((row >> 2) & 0x01) A3_HIGH(); else A3_LOW();
    row >>= 3;
    switch(row)
    {
        case 0: OE1_HIGH();OE2_LOW(); OE3_LOW(); OE4_LOW();break;
        case 1: OE1_LOW(); OE2_HIGH();OE3_LOW(); OE4_LOW();break;
        case 2: OE1_LOW(); OE2_LOW(); OE3_HIGH();OE4_LOW();break;
        case 3: OE1_LOW(); OE2_LOW(); OE3_LOW(); OE4_HIGH();break;
    }
}

//发送8bit的74HC595列数据
void send_column(u8 dat1,u8 dat2,u8 dat3,u8 dat4)
{
  u8 i;
  for(i=0;i<8;i++)
  {
    if(dat4&0x01) 
      SER_HIGH();
	  else
	    SER_LOW();
    CLK_HIGH();
	  dat4>>=1;
    CLK_LOW();
  }

  for(i=0;i<8;i++)
  {
    if(dat3&0x01) 
      SER_HIGH();
    else
      SER_LOW();
    CLK_HIGH();
    dat3>>=1;
    CLK_LOW();
  }

  for(i=0;i<8;i++)
  {
    if(dat2&0x01) 
      SER_HIGH();
    else
      SER_LOW();
    CLK_HIGH();
    dat2>>=1;
    CLK_LOW();
  }

  for(i=0;i<8;i++)
  {
    if(dat1&0x01) 
      SER_HIGH();
    else
      SER_LOW();
    CLK_HIGH();
    dat1>>=1;
    CLK_LOW();
  }
  RCK_HIGH();
  RCK_LOW();
}

void clean_column()
{
  SER_HIGH(); 
  for(u8 i=0;i<32;i++)
  {
      CLK_HIGH();
      NOP();
      CLK_LOW();
  }
  RCK_HIGH();
  NOP();
  RCK_LOW();
}

void scan_one_frame()
{
    for(u8 ii=0;ii<32;ii++)
    {
        HC138Disable();
        send_column(matrix_buf[ii][0],matrix_buf[ii][1],matrix_buf[ii][2],matrix_buf[ii][3]);
        scanning_row(ii);
        delay_us(50);
    }
}
