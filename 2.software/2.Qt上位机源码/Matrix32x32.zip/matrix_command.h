#ifndef MATRIXCOMMAND_H
#define MATRIXCOMMAND_H

#include <QtGlobal>


#define CMD_FLAG        0xEE
#define RESULT_FLAG     0xEF
#define CMD_LEN         10

#define CMD_GIF         0x01  //播放GIF动画命令

//GIF相关命令
#define GIF_CMD_SPEED   0xE0
#define GIF_CMD_STOP    0xE2

//设置线程状态相关
#define SEND_THREAD_STOP    0
#define SEND_THREAD_PAUSE   1
#define SEND_THREAD_RUN     2

//发送数据相关
#define SEND_TO_SERIAL      1
#define SEND_TO_THREAD      2

class MatrixCommand
{
public:
    static quint8* createPlayGifCmd(int frameCount);
    static quint8* createExitGifCmd();
    static quint8* createSpeedGifCmd(quint8 speed);

};

#endif // MATRIXCOMMAND_H
