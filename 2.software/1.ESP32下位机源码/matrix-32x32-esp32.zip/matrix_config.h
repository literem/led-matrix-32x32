#ifndef __MATRIX_CONFIG_H
#define __MATRIX_CONFIG_H

typedef unsigned char u8;
typedef unsigned int u16;

#endif
