#ifndef SEND_DATA_ARRAY_H
#define SEND_DATA_ARRAY_H

#include <QtGlobal>
#include <cstring>

class SendDataArray
{
public:
    SendDataArray(int size) : arraySize(size),array(new quint8[size]){}
    ~SendDataArray()
    {
        delete[] array;
    }
    void copyToArray(char* dat,int len)
    {
        memcpy(array,dat,len);
    }
public:
    int arraySize;
    quint8* array;
};

#endif // SEND_DATA_ARRAY_H
