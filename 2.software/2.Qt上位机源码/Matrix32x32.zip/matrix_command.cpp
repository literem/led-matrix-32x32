#include "matrix_command.h"


quint8* MatrixCommand::createPlayGifCmd(int frameCount)
{
    quint8* cmd =  new quint8[10];
    cmd[0] = cmd[1] = 0xff;
    cmd[2] = CMD_FLAG;
    cmd[3] = CMD_LEN;
    cmd[4] = cmd[5] = CMD_GIF;
    cmd[6] = frameCount >> 8;
    cmd[7] = frameCount & 0xff;
    cmd[8] = cmd[9] = 0xff;
    return cmd;
}

quint8* MatrixCommand::createExitGifCmd()
{
    quint8* cmd =  new quint8[10];
    cmd[0] = cmd[1] = 0xff;
    cmd[2] = CMD_FLAG;
    cmd[3] = CMD_LEN;
    cmd[4] = cmd[5] = GIF_CMD_STOP;
    cmd[6] = cmd[7] = 0;
    cmd[8] = cmd[9] = 0xff;
    return cmd;
}

quint8 *MatrixCommand::createSpeedGifCmd(quint8 speed)
{
    quint8* cmd =  new quint8[10];
    cmd[0] = cmd[1] = 0xff;
    cmd[2] = CMD_FLAG;
    cmd[3] = CMD_LEN;
    cmd[4] = cmd[5] = GIF_CMD_SPEED;
    cmd[6] = 0;
    cmd[7] = speed;
    cmd[8] = cmd[9] = 0xff;
    return cmd;
}
