#ifndef PAGE4TOOLS_H
#define PAGE4TOOLS_H

#include <QWidget>

namespace Ui {
class Page4Tools;
}

class Page4Tools : public QWidget
{
    Q_OBJECT

public:
    explicit Page4Tools(QWidget *parent = nullptr);
    ~Page4Tools();

private slots:
    void on_buttonChoose_clicked();

    void on_button_parse_image_clicked();

    void on_button_parse_array_clicked();

    void on_button_clean_clicked();

    void on_horizontalSlider_valueChanged(int value);

private:
    QString getSavePath(void);

    void textInfoAppend(QString text);

private:
    Ui::Page4Tools *ui;

    int towSideValue = 128;
};

#endif // PAGE4TOOLS_H
