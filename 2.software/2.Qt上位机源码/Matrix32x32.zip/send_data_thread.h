#ifndef SEND_DATA_THREAD_H
#define SEND_DATA_THREAD_H


#include "send_data_array.h"

#include <QThread>
#include <QList>
#include <QMutex>
#include <QWaitCondition>
#include <QDebug>

#define SEND_ING        1
#define SEND_STOP       2
#define SEND_PAUSE      3

class SendDataThread : public QThread
{
    Q_OBJECT

public:
    ~SendDataThread()
    {
        isLoop = false;
    }

Q_SIGNALS:
    void sendData(quint8* dat,quint16 len);

public:
    //设置list数据，并开始线程
    void setListAndStart(QList<SendDataArray*> *list)
    {
        this->list = list;
        frameIndex = 0;
        frameCount = list->size();
        setSendStatus(SEND_ING);
        wakeUp();
    }

    //设置线程状态
    void setSendStatus(int status)
    {
        sendStatus = status;
    }

    //唤醒线程
    void wakeUp()
    {
        QMutexLocker locker(&mutex);
        condition.wakeOne();
    }

    //唤醒线程并退出
    void wakeUpAndExit()
    {
        qDebug() << "wakeUpAndExit()";
        isLoop = false;
        isResponse = false;
        sendStatus = SEND_STOP;
        wakeUp();
    }

    //设置下一帧数据索引
    void setReqeustFrameIndex(quint16 index)
    {
        frameIndex = index;
        isResponse = true;
    }

    //添加发送命令
    void addSendingCmd(quint8* data,quint8 len)
    {
        cmdArray = data;
        cmdArrayLen = len;
        hasCmdTask = true;
    }

private:
    QWaitCondition condition;
    QMutex mutex;
    QList<SendDataArray*> *list = nullptr;
    bool isLoop;
    int frameCount;
    int frameIndex = 0;
    bool isResponse = false;
    int sendStatus = SEND_STOP;
    quint8* cmdArray;
    quint8 cmdArrayLen;
    bool hasCmdTask = false;

    //等待回应
    void waitResponse()
    {
        isResponse = false;
        while(isLoop)
        {
            if(isResponse) return;
            msleep(10);
        }
    }

    //检查是否有命令需要发送的
    bool checkCmdTask()
    {
        if(hasCmdTask)
        {
            hasCmdTask = false;
            if(cmdArray == nullptr) return false;
            emit sendData(cmdArray,cmdArrayLen);
            delete[] cmdArray;
            cmdArray = nullptr;
            return true;
        }
        return false;
    }

public:
    void run() override
    {
        QMutexLocker locker(&mutex);
        isLoop = true;
        while(isLoop)
        {
            while(sendStatus != SEND_STOP)
            {
                if(list == nullptr || list->size() == 0)
                {
                    sendStatus = SEND_STOP;
                    break;
                }
                //等待回应
                waitResponse();

                //如果有命令就发送命令
                if(checkCmdTask()) continue;

                //发送帧数据
                if(sendStatus == SEND_ING && frameIndex >=0 && frameIndex < frameCount)
                {
                    emit sendData(list->at(frameIndex)->array,list->at(frameIndex)->arraySize);
                }
            }

            //退出后再次判断，有命令就发送命令
            checkCmdTask();

            if(list != nullptr && list->size() != 0)
            {
                qDeleteAll(*list);
                list->clear();
                delete list;
                list = nullptr;
            }
            msleep(50);
            qDebug() << "thread sleeping...";

            if(isLoop) condition.wait(&mutex);//线程挂起，直到调用wakeUp函数后，继续往下执行
        }
        qDebug() << "thread exit!";
    }
};

#endif // SEND_DATA_THREAD_H
