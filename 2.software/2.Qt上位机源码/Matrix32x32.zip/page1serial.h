#ifndef PAGE1SERIAL_H
#define PAGE1SERIAL_H

#include "send_data_thread.h"
#include "send_data_array.h"

#include <QWidget>
#include <QSerialPort>
#include <QList>


namespace Ui {
class Page1Serial;
}

class Page1Serial : public QWidget
{
    Q_OBJECT

public:
    explicit Page1Serial(QWidget *parent = nullptr);
    ~Page1Serial();

    void sendOneData(quint8* dat,int len,int flag);
    void sendListData(QList<SendDataArray*> *list);
    void setThreadStatus(int status);

Q_SIGNALS:
    void updateProgress(int value);

private slots:
    void on_buttonOpenSerial_clicked();

    void on_buttonScanSerial_clicked();



private:
    Ui::Page1Serial *ui;
    bool isOpened = false;
    QSerialPort* serialPort = nullptr;
    SendDataThread* sendThread = nullptr;
private:
    void openSerial();
    void closeSerial();
    void readData();
    QString getSerialPort();
    QSerialPort::BaudRate getSerialBaudRate();
    void setSerialStatusButton(bool status);
    void sendDataToSerial(quint8* dat, quint16 len);

};

#endif // PAGE1SERIAL_H
