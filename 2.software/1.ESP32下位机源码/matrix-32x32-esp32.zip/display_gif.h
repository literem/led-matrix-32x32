#ifndef DISPLAY_GIF_H
#define DISPLAY_GIF_H

#include "matrix_config.h"

#define GIF_RUN    1
#define GIF_STOP   0

void display_gif_init(u16 gif_len);
void display_gif();

#endif
