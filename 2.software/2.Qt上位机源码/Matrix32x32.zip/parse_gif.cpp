#include "parse_gif.h"

#include <QList>
#include <QImage>
#include <QFile>
#include <QDebug>
#include <QDir>


//解析GIF
int ParseGIF::parseGIF(QString dirPath)
{
    if(dirPath == nullptr)  return PARSE_PATH_NULL;

    QString baseAddr = dirPath + QString("\\");
    QDir dir(baseAddr);
    if(!dir.exists()) return PARSE_PATH_NULL;
    QStringList fileList = dir.entryList();
    int size = fileList.size() - 3;
    if(size <= 0) return PARSE_PATH_EMPTY;

    QList<quint8*> *list = new QList<quint8*>();
    for (int i = 0; i < size; i+=2) {
        quint8* array = parseOneImage(baseAddr + QString::number(i) + ".png",128);
        if(array == nullptr) continue;
        list->append(array);
    }

    saveBinArray(list,"D:\\test.bin");

    qDeleteAll(*list);
    return PARSE_SUCCESS;
}

//根据图片路径解析一张图片，返回二进制数组
quint8* ParseGIF::parseOneImage(QString imgPath,int value)
{
    if(imgPath.isEmpty())
    {
        qDebug() << "图片路径为空";
        return nullptr;
    }
    QImage img = QImage();
    if(!(img.load(imgPath))) //加载图像
    {
        qDebug() << "打开图像失败!";
        return nullptr;
    }

    float mul;
    if(img.width() >= img.height())
        mul = img.width() / 32.0;
    else
        mul = img.height() / 32.0;

    quint8* result;
    if(mul == 0.0)
    {
        result = imageToBinArray(img,value);
    }
    else
    {
        QImage scalc = img.scaled(img.width() / mul, img.height() / mul, Qt::KeepAspectRatio);
        result = imageToBinArray(scalc,value);
    }
    return result;
}

//根据QImage解析一张图片，返回二进制数组
quint8 *ParseGIF::parseOneImage(QImage &img,int value)
{
    float mul;
    if(img.width() >= img.height())
        mul = img.width() / 32.0;
    else
        mul = img.height() / 32.0;

    quint8* result;
    if(mul == 0.0)
    {
        result = imageToBinArray(img,value);
    }
    else
    {
        QImage scalc = img.scaled(img.width() / mul, img.height() / mul, Qt::KeepAspectRatio);
        result = imageToBinArray(scalc,value);
    }
    return result;
}

bool ParseGIF::saveBinArray(QList<quint8 *> *list, QString filePath)
{
    QFile file(filePath);
    if (file.open(QIODevice::WriteOnly))
    {
        QDataStream stream(&file);

        QList<quint8*>::iterator it;
        for(it = list->begin(); it != list->end(); ++it)
        {
            stream.writeRawData(reinterpret_cast<char *>(*it), 128);
        }

        // 使用输出字符写数据，可以写字符串，也可以整型，或者其他类型的数据；
        // 注意：因为写入的是二进制数据，所以即使写入的是 .txt 文件，文件中也是乱码；
        file.close(); // 关闭文件
        qDebug("文件保存成功");
        return true;
    }
    else
    {
        qDebug("文件保存失败");
        return false;
    }
}

void ParseGIF::setReverse(bool reverse)
{
    this->isReverse = reverse;
}

//图片转二进制数组
quint8 *ParseGIF::imageToBinArray(QImage &img,int value)
{
    int width = img.width();
    int height = img.height();
    if(width > 32 || height > 32) return nullptr;

    int h=0,w=0;
    quint32 lowBit;
    QColor oldColor;
    int ts;
    quint8 *temp = new quint8[128];
    if(height != 32)
    {
        h = (32 - height) / 2;
        height = height + h;
        memset(temp,0xff,128);
    }
    if(width != 32)
    {
        w = (32 - width) / 2;
        lowBit = 0xffffffff;
        lowBit >>= (32 - w);
    }

    quint32 num;
    quint8 x;
    for (char y=0; h < height; ++h,++y)
    {
        for (x=0,num=0xffffffff; x < width; ++x)
        {
            oldColor = QColor(img.pixel(x,y));
            ts = oldColor.red();
            if(isReverse)
            {
                if(ts > value) num |= 0x00000001;
            }
            else
            {
                if(ts < value) num |= 0x00000001;
            }
            num <<= 1;
        }
        if(w != 0)
        {
            num <<= w;
            num |= lowBit;
        }
        num |= 0x00000001;
        temp[h*4]   = num >> 24;
        temp[h*4+1] = num >> 16;
        temp[h*4+2] = num >> 8;
        temp[h*4+3] = num & 0xff;
    }
    return temp;
}
