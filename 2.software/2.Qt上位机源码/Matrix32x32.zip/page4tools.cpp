#include "page4tools.h"
#include "parse_gif.h"
#include "ui_page4tools.h"

#include <QFileDialog>
#include <QDebug>
#include <QMessageBox>
#include <QMovie>

QString path;

Page4Tools::Page4Tools(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Page4Tools)
{
    ui->setupUi(this);
}

Page4Tools::~Page4Tools()
{
    delete ui;
}

QString Page4Tools::getSavePath()
{
    QString directory = QFileDialog::getExistingDirectory(this,tr("选择图片路径"),QDir::currentPath());
    directory.replace("\\","/"); //双斜杠转换单斜杠
    if(!directory.isEmpty())
    {
        return directory;
    }
    return QString();
}


void Page4Tools::textInfoAppend(QString text)
{
    QDateTime currentTime = QDateTime::currentDateTime();
    ui->textInfo->append(currentTime.toString("yyyy-MM-dd HH:mm:ss ->>>") + text);
}

void Page4Tools::on_buttonChoose_clicked()
{
    QString filename = QFileDialog::getOpenFileName(this,tr("选择GIF图像"),"",tr("Images (*.gif)"));
    if(filename.isEmpty())
    {
        textInfoAppend("没有选择任何GIF图像");
        return;
    }
    QImage* img = new QImage,* scaledimg = new QImage;//分别保存原图和缩放之后的图片
    if(!(img->load(filename))) //加载图像
    {
        delete img;
        delete scaledimg;
        QMessageBox::warning(this,"提示","打开图像失败!");
        textInfoAppend("打开GIF图像失败");
        return;
    }
    int o_width = img->width();
    int o_height = img->height();

    if(o_width > 70 || o_height > 70)
    {
        float Mul;
        if(o_width >= o_height)
            Mul = o_width / 70.0;
        else
            Mul = o_height / 70.0;
        *scaledimg = img->scaled(o_width / Mul,o_height / Mul,Qt::KeepAspectRatio);
        ui->image_gif_preview->setPixmap(QPixmap::fromImage(*scaledimg));
    }
    else
    {
        ui->image_gif_preview->setPixmap(QPixmap::fromImage(*img));
    }
    delete scaledimg;
    delete img;
    path = filename;
    textInfoAppend("选择的GIF图像路径为："+filename);
}

//把gif拆分成图片
void Page4Tools::on_button_parse_image_clicked()
{
    if(path == nullptr || path.isEmpty())
    {
        QMessageBox::warning(this,"提示","请选择一张GIF图片的路径再进行转换");
        textInfoAppend("请选择一张GIF图像的路径再进行转换");
        return;
    }
    QMovie *movie = new QMovie();
    movie->setFileName(path);
    movie->setCacheMode(QMovie::CacheAll);
    if(movie == nullptr)
    {
        QMessageBox::warning(this,"提示","GIF图片拆分失败");
        textInfoAppend("GIF图像拆分失败");
        return;
    }

    QString savePath = getSavePath();
    textInfoAppend("GIF图像拆分后保存的路径为：" + savePath);
    if(!savePath.isNull())
    {
        int nNum = movie->frameCount();
        for(int i = 0; i < nNum; i++)
        {
            QString strImageName = savePath + QString("/") + QString::number(i) + ".png";
            qDebug() << strImageName;
            movie->jumpToFrame(i);
            QImage img = movie->currentImage();
            img.save(strImageName,"png");
            textInfoAppend("已图片保存到：" + strImageName);
        }
    }
    delete movie;
}

//gif解析为32x32像素的二进制数组
void Page4Tools::on_button_parse_array_clicked()
{
    //判断路径
    if(path == nullptr || path.isEmpty())
    {
        QMessageBox::warning(this,"提示","请选择一张GIF图像的路径再进行转换");
        textInfoAppend("请选择一张GIF图像的路径再进行转换");
        return;
    }

    //准备GIF对象，为了避免栈溢出，把对象放到堆里
    QMovie *movie = new QMovie();
    movie->setFileName(path);
    movie->setCacheMode(QMovie::CacheAll);
    if(movie == nullptr)
    {
        QMessageBox::warning(this,"提示","GIF图像加载失败");
        textInfoAppend("GIF图像加载失败");
        return;
    }

    //逐帧解析，并添加到list中
    int count = movie->frameCount();
    QList<quint8*> *list = new QList<quint8*>();
    ParseGIF parse = ParseGIF();
    parse.setReverse(ui->checkBox->isChecked());
    for (int i = 0; i < count; i++)
    {
        movie->jumpToFrame(i);
        QImage img = movie->currentImage();
        quint8* array = parse.parseOneImage(img,towSideValue);
        if(array == nullptr) continue;
        list->append(array);
    }

    //保存二进制数组文件
    QString binArrayPath = QDir::currentPath() + "/binArray";
    QDir dir = QDir(binArrayPath);
    if(!dir.exists())
    {
        dir.mkdir(binArrayPath);
    }
    QString savePath = QFileDialog::getSaveFileName(this,"选择保存二进制数组文件的路径",dir.path(),"Bin Files (*.bin)",nullptr);
    if(savePath.isEmpty())
    {
        QMessageBox::warning(this,"提示","保存失败，没有选择保存路径");
        textInfoAppend("保存失败，没有选择保存路径");
        goto finish;
    }
    if(parse.saveBinArray(list,savePath))
    {
        textInfoAppend("二进制数组已成功保存到：" + savePath);
    }
    else
    {
        textInfoAppend("二进制数组保存失败");
    }

    finish:
    //删除对象（占用内存大的对象，使用new分配到堆空间上，避免栈溢出）
    qDeleteAll(*list);
    delete movie;
}

void Page4Tools::on_button_clean_clicked()
{
    ui->textInfo->clear();
}

void Page4Tools::on_horizontalSlider_valueChanged(int value)
{
    ui->label_grey->setText("二值化阈值：" + QString::number(value) + "/255");
    towSideValue = value;
}

