#ifndef __SCANNING_H
#define __SCANNING_H

#include "matrix_config.h"

extern u8 matrix_buf[32][4];

#define set_matrix_buf(y,x,dat)     matrix_buf[y][x]=dat
#define get_matrix_buf(y,x)         matrix_buf[y][x]
#define matrix_buf_data_up(y,x)     matrix_buf[y][x]=matrix_buf[y+1][x]
#define matrix_buf_data_down(y,x)   matrix_buf[y][x]=matrix_buf[y-1][x]

void scanning_init(void);
void scanning_row(u8 row);
void send_column(u8 dat1,u8 dat2,u8 dat3,u8 dat4);
void scan_one_frame(void);

#endif
