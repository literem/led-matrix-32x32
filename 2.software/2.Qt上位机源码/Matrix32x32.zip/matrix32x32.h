#ifndef MATRIX32X32_H
#define MATRIX32X32_H

#include <QWidget>
#include <QPaintEvent>
#include <QPainter>
#include <QPen>
#include <QMouseEvent>
#include <QDebug>
#include <QVector>

#define START_X     5
#define START_Y     5
#define PADDING_X   15
#define PADDING_Y   15
#define RADIUS      10

namespace Ui {
class matrix32x32;
}

class matrix32x32 : public QWidget
{
    Q_OBJECT

public:
    explicit matrix32x32(QWidget *parent = nullptr);
    ~matrix32x32();

    quint8 *getBuff();
    void createHex(quint8 **result);
    void setBuff(int x,int y,quint8 v);
    void cleanBuff();
    void refresh();
    void shiftLeft();
    void shiftRight();

private:
    Ui::matrix32x32 *ui;

    void paintEvent(QPaintEvent *event);

    quint8 binToHex(quint8 y,quint8 x);
};

#endif // MATRIX32X32_H
