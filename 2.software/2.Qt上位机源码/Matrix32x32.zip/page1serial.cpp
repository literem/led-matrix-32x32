#include "page1serial.h"
#include "ui_page1serial.h"

#include <QDebug>
#include <QMessageBox>
#include <QDateTime>
#include <QDialog>
#include <QList>

#include <QSerialPortInfo>

#include "matrix_command.h"

Page1Serial::Page1Serial(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Page1Serial)
{
    ui->setupUi(this);
    ui->comboBoxBaudRate->setCurrentText("19200");

    QList<QSerialPortInfo> ports = QSerialPortInfo::availablePorts();
    if(ports.count() != 0)
    {
        ui->comboBoxSerial->clear();
        foreach (QSerialPortInfo info, ports)
        {
            ui->comboBoxSerial->addItem(info.portName() + " " + info.description());
        }
    }

    sendThread = new SendDataThread();
    sendThread->start();
    connect(sendThread,&SendDataThread::sendData,this,&Page1Serial::sendDataToSerial);
}

Page1Serial::~Page1Serial()
{
    delete ui;
    delete serialPort;
    if(sendThread != nullptr)
    {
        sendThread->wakeUpAndExit();
        QThread::msleep(150);
        delete sendThread;
    }
}

//发送数据到串口
void Page1Serial::sendDataToSerial(quint8* dat, quint16 len)
{
    if(serialPort == nullptr) return;
    if(!serialPort->isOpen()) return;
    serialPort->write((char*)dat,len);
}

//发送一条数据，flag：立即发送到串口，或者发送到线程
void Page1Serial::sendOneData(quint8* dat,int len,int flag)
{
    if(flag == SEND_TO_THREAD)
    {
        sendThread->addSendingCmd(dat,len);
        return;
    }

    if(serialPort == nullptr)
    {
        QMessageBox::warning(this,"提示","数据发送失败，串口对象为空！");
        return;
    }

    if(!serialPort->isOpen())
    {
        QMessageBox::warning(this,"提示","数据发送失败，串口未打开！");
        return;
    }

    int result = serialPort->write((char*)dat,len);
    if(result == -1)
    {
        QMessageBox::warning(this,"提示","数据发送失败，请检查串口是否连接正常！");
    }
}

//发送列表数据，该数据会被提交到线程里发送
void Page1Serial::sendListData(QList<SendDataArray*> *list)
{
    if(serialPort == nullptr)
    {
        return;
    }
    if(!serialPort->isOpen())
    {
        return;
    }
    if(sendThread == nullptr) return;
    sendThread->setListAndStart(list);
}

void Page1Serial::setThreadStatus(int status)
{
    if(status == SEND_THREAD_STOP)
    {
        sendThread->setSendStatus(SEND_STOP);
    }
    else if(status == SEND_THREAD_PAUSE)
    {
        sendThread->setSendStatus(SEND_PAUSE);
    }
    else if(status == SEND_THREAD_RUN)
    {
        sendThread->setSendStatus(SEND_ING);
    }
}

void Page1Serial::on_buttonOpenSerial_clicked()
{
    if(serialPort == nullptr)
    {
        serialPort = new QSerialPort();
        serialPort->setDataBits(QSerialPort::Data8);// 设置数据位数
        serialPort->setStopBits(QSerialPort::OneStop);// 设置停止位数
        serialPort->setParity(QSerialPort::NoParity);// 设置奇偶校验位
        serialPort->setFlowControl(QSerialPort::NoFlowControl);// 设置流控制
    }

    if(serialPort->isOpen()!=isOpened)
    {
        closeSerial();
        QMessageBox::warning(this,"提示","串口发生错误，请重新打开");
        return;
    }

    if(serialPort->isOpen())
    {
        closeSerial();
    }
    else
    {
        openSerial();
    }
}


void Page1Serial::on_buttonScanSerial_clicked()
{
    QList<QSerialPortInfo> ports = QSerialPortInfo::availablePorts();
    if(ports.count() == 0)
    {
        ui->comboBoxSerial->clear();
        return;
    }
    ui->comboBoxSerial->clear();
    foreach (QSerialPortInfo info, ports)
    {
        ui->comboBoxSerial->addItem(info.portName() + " " + info.description());
    }
}

void Page1Serial::openSerial()
{
    QString com = getSerialPort();
    QSerialPort::BaudRate baudRate = getSerialBaudRate();

    if(com.size() == 0)
    {
        QMessageBox::warning(this,"提示","请选择一个串口号");
        return;
    }

    if(baudRate == QSerialPort::UnknownBaud)
    {
        QMessageBox::warning(this,"提示","请选择一个正确的波特率");
        return;
    }

    serialPort->setPortName(com);// 设置串口名称
    serialPort->setBaudRate(baudRate);// 设置波特率

    if(serialPort->open(QIODevice::ReadWrite))
    {
        isOpened = true;
        setSerialStatusButton(serialPort->isOpen());
        connect(serialPort, &QSerialPort::readyRead, this, &Page1Serial::readData);
        if(sendThread == nullptr)
        {
            sendThread = new SendDataThread();
            connect(sendThread,&SendDataThread::sendData,this,&Page1Serial::sendDataToSerial);
            sendThread->start();
        }
    }
    else
    {
        QString errMsg;
        QSerialPort::SerialPortError e = serialPort->error();
        switch(e)
        {
            case QSerialPort::TimeoutError:errMsg = "串口打开超时";break;
            case QSerialPort::NoError:break;
            case QSerialPort::DeviceNotFoundError:errMsg = "串口打开失败，串口设备未找到";break;
            case QSerialPort::PermissionError:errMsg = "串口打开失败，权限访问受限";break;
            case QSerialPort::OpenError:errMsg = "串口打开错误";break;
            case QSerialPort::ParityError:
            case QSerialPort::FramingError:
            case QSerialPort::BreakConditionError:
            case QSerialPort::WriteError:
            case QSerialPort::ReadError:errMsg = "串口打开失败";break;
            case QSerialPort::ResourceError:errMsg = "串口打开失败，资源错误";break;
            case QSerialPort::UnsupportedOperationError:errMsg = "串口打开失败，不支持的操作";break;
            case QSerialPort::UnknownError:errMsg = "串口打开失败，未知错误";break;
            case QSerialPort::NotOpenError:break;
        }
        QMessageBox::warning(this,"提示",errMsg);
    }
}

void Page1Serial::closeSerial()
{
    if(serialPort->isOpen())
    {
        serialPort->clear();
        serialPort->close();
    }
    if(sendThread != nullptr)
    {
        sendThread->wakeUpAndExit();
        QThread::msleep(100);
        delete sendThread;
        sendThread = nullptr;
    }
    setSerialStatusButton(false);
    isOpened = false;
}

void Page1Serial::readData()
{
    QByteArray buf = serialPort->readAll();
    quint8* dat = (quint8*)buf.data();
    quint16 len = buf.size();
    if(len >= 8)
    {
        if(dat[0]!=0xff || dat[7]!=0xff) return;
        if(dat[1]!=0xEF || dat[2]!=10) return;
        len = (dat[3]<<8) + dat[4];
        sendThread->setReqeustFrameIndex(len);
        emit updateProgress(len);
        return;
    }
    buf.clear();
}

QString Page1Serial::getSerialPort()
{
    QString com = ui->comboBoxSerial->currentText();
    return com.left(4);
}

QSerialPort::BaudRate Page1Serial::getSerialBaudRate()
{
    switch(ui->comboBoxBaudRate->currentIndex())
    {
        case 0:  return QSerialPort::Baud1200;
        case 1:  return QSerialPort::Baud2400;
        case 2:  return QSerialPort::Baud4800;
        case 3:  return QSerialPort::Baud9600;
        case 4:  return QSerialPort::Baud19200;
        case 5:  return QSerialPort::Baud38400;
        case 6:  return QSerialPort::Baud57600;
        case 7:  return QSerialPort::Baud115200;
        default: return QSerialPort::UnknownBaud;
    }
}

void Page1Serial::setSerialStatusButton(bool status)
{
    if(status)
    {
        //设置打开后的状态
        ui->buttonOpenSerial->setText("关闭串口");
        ui->buttonOpenSerial->setStyleSheet("background:rgb(255, 0, 0);border-radius:10px;color:white;");
    }
    else
    {
        //设置关闭后的状态
        ui->buttonOpenSerial->setText("打开串口");
        ui->buttonOpenSerial->setStyleSheet("background:rgb(0, 170, 255);border-radius:10px;color:white;");
    }
}

