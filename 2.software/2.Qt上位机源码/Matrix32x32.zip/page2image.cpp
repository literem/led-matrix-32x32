#include "page2image.h"
#include "ui_page2image.h"
#include <QFileDialog>
#include <QMessageBox>
#include <QMovie>
#include <QBitmap>
#include <QClipboard>

Page2Image::Page2Image(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Page2Image)
{
    ui->setupUi(this);
}

Page2Image::~Page2Image()
{
    delete ui;
}

//选择图片
void Page2Image::on_buttonSelectImage_clicked()
{
    QString filename;
    filename = QFileDialog::getOpenFileName(this,tr("选择图像"),"",tr("Images (*.png *.bmp *.jpg)"));
    if(filename.isEmpty())
    {
        return;
    }

    QImage* img = new QImage,* scaledimg = new QImage;//分别保存原图和缩放之后的图片

    if(!(img->load(filename))) //加载图像
    {
        delete img;
        delete scaledimg;
        QMessageBox::warning(this,"打开图像失败","打开图像失败!");
        return;
    }
    int o_width = img->width();
    int o_height = img->height();

    if(o_width > 70 && o_height > 70)
    {
        float Mul;
        if(o_width >= o_height)
            Mul = o_width / 32.0;
        else
            Mul = o_height / 32.0;
        *scaledimg = img->scaled(o_width / Mul,o_height / Mul,Qt::KeepAspectRatio);
        ui->labelImage->setPixmap(QPixmap::fromImage(*scaledimg));
    }
    else
    {
        ui->labelImage->setPixmap(QPixmap::fromImage(*img));
    }

    this->imgPath = filename;
    delete scaledimg;
    delete img;
}


//二值化
void Page2Image::twoSide(QImage& grayimage,int value)
{
    //grayimage.convertToFormat(QImage::Format_ARGB32);
    QColor oldColor;
    int ts;
    quint8 isReverse = ui->reverseCheckBox->isChecked() ? 1 : 0;
    //int offset = ui->centerCheckBox->isChecked() ? (40-grayimage.width())/2 : 0;

    int y,x,x_start;
    int offset = 0;
    ui->matrix->cleanBuff();
    for(y = 0; y < grayimage.height(); y++)
    {
        for(x = 0,x_start = offset; x < grayimage.width(); x++,x_start++)
        {
            oldColor = QColor(grayimage.pixel(x,y));
            ts = oldColor.red();
            if(ts<value){
                //ts=0;
                ui->matrix->setBuff(y,x_start,isReverse);
            }else{
                //ts=255;
                ui->matrix->setBuff(y,x_start,!isReverse);
            }
            //TwoSideImage.setPixel(x,y, qRgb(ts, ts, ts));
        }
    }
    ui->matrix->refresh();
    ui->labelImage->setPixmap(QPixmap::fromImage(grayimage));
}


//灰度化
QImage Page2Image::gray(QImage& image)
{
    QImage newImage = image.convertToFormat(QImage::Format_ARGB32);
    QColor oldColor;
    for(int y = 0; y < newImage.height(); y++)
    {
        for(int x = 0; x < newImage.width(); x++)
        {
            oldColor = QColor(image.pixel(x,y));
            int average = (oldColor.red() + oldColor.green() + oldColor.blue()) / 3;
            newImage.setPixel(x, y, qRgb(average, average, average));
        }
    }
    return newImage;
}

//图片转换
void Page2Image::transferImage(QString path)
{
    if(path.isEmpty())
    {
        QMessageBox::warning(this,"提示","图片转换失败，图片路径为空");
        return;
    }
    QImage* img = new QImage;
    if(!(img->load(path))) //加载图像
    {
        QMessageBox::information(this,tr("提示"),tr("打开图像失败!"));
        delete img;
        return;
    }

    float mul;
    if(img->width() >= img->height())
        mul = img->width() / 32.0;
    else
        mul = img->height() / 32.0;

    QImage grayimage;
    if(mul == 0)
    {
        grayimage = gray(*img);
        twoSide(grayimage,towSideValue);
    }
    else
    {
        QImage scalc = img->scaled(img->width() / mul, img->height() / mul, Qt::KeepAspectRatio);
        grayimage = gray(scalc);
        twoSide(grayimage,towSideValue);
    }
    delete img;
}

//图片转换按钮点击事件
void Page2Image::on_buttonImageTransfer_clicked()
{
    if(imgPath == nullptr || imgPath.isEmpty())
    {
        QMessageBox::warning(this,"提示","请先选择图片后再转换");
        return;
    }
    transferImage(imgPath);
}

//发送按钮点击事件
void Page2Image::on_buttonSend_clicked()
{
    quint8 temp[128];
    quint8 *t = temp;
    ui->matrix->createHex(&t);

    QString text = "";
    for (int j = 0; j < 128; ++j)
    {
        if(temp[j] < 10)
        {
            text += "0x0" + QString::number(temp[j],16) + ",";
        }
        else
        {
            text += "0x" + QString::number(temp[j],16) + ",";
        }
    }
    QClipboard *clipboard = QApplication::clipboard();   //获取系统剪贴板指针
    clipboard->setText(text);
    QMessageBox::information(this,"信息","已将128字节的十六进制数据复制到剪切板");

    //emit sendSerialData(temp,128,SEND_TO_SERIAL);
}

//进度条滑动事件
void Page2Image::on_horizontalSlider_valueChanged(int value)
{
    ui->label_grey->setText("二值化阈值：" + QString::number(value) + "/255");
    towSideValue = value;
}
