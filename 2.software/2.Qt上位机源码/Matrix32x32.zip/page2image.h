#ifndef PAGE2IMAGE_H
#define PAGE2IMAGE_H

#include <QWidget>
#include <QImage>

namespace Ui {
class Page2Image;
}

class Page2Image : public QWidget
{
    Q_OBJECT

public:
    explicit Page2Image(QWidget *parent = nullptr);
    ~Page2Image();

Q_SIGNALS:
    void sendSerialData(quint8* dat,int len,int flag);

private slots:
    void on_buttonSelectImage_clicked();

    void on_buttonImageTransfer_clicked();

    void on_buttonSend_clicked();

    void on_horizontalSlider_valueChanged(int value);

private:
    Ui::Page2Image *ui;

    QString imgPath;

    int towSideValue = 128;

    void transferImage(QString path);

    void twoSide(QImage& grayimage,int value);

    QImage gray(QImage& image);
};

#endif // PAGE2IMAGE_H
