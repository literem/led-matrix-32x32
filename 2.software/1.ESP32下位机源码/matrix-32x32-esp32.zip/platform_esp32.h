#ifndef __PLATFORM_STM32_H
#define __PLATFORM_STM32_H

#include "Arduino.h"

#define delay_us(t)   delayMicroseconds(t)
#define delay_ms(t)   delay(t)
#define NOP()

//引脚配置
#define A1_138  	12
#define A2_138  	14
#define A3_138  	27
#define OE1_138  	32
#define OE2_138  	33
#define OE3_138  	25
#define OE4_138		26

#define SER 		2
#define CLK 		13
#define RCK 		15
#define OE_595		4

//74hc138
#define A1_HIGH()   digitalWrite(A1_138,HIGH)
#define A1_LOW()    digitalWrite(A1_138,LOW)
#define A2_HIGH()   digitalWrite(A2_138,HIGH)
#define A2_LOW()    digitalWrite(A2_138,LOW)
#define A3_HIGH()   digitalWrite(A3_138,HIGH)
#define A3_LOW()    digitalWrite(A3_138,LOW)

#define OE1_HIGH()   digitalWrite(OE1_138,HIGH)
#define OE1_LOW()    digitalWrite(OE1_138,LOW)
#define OE2_HIGH()   digitalWrite(OE2_138,HIGH)
#define OE2_LOW()    digitalWrite(OE2_138,LOW)
#define OE3_HIGH()   digitalWrite(OE3_138,HIGH)
#define OE3_LOW()    digitalWrite(OE3_138,LOW)
#define OE4_HIGH()   digitalWrite(OE4_138,HIGH)
#define OE4_LOW()    digitalWrite(OE4_138,LOW)


//74hc595
#define SER_HIGH()  digitalWrite(SER,HIGH)
#define SER_LOW()   digitalWrite(SER,LOW)
#define CLK_HIGH()  digitalWrite(CLK,HIGH)
#define CLK_LOW()   digitalWrite(CLK,LOW)
#define RCK_HIGH()  digitalWrite(RCK,HIGH)
#define RCK_LOW()   digitalWrite(RCK,LOW)
#define ENABLE_595() digitalWrite(OE_595,LOW)


void scanning_init()
{
  pinMode(A1_138,OUTPUT);
  pinMode(A2_138,OUTPUT);
  pinMode(A3_138,OUTPUT);
  pinMode(OE1_138,OUTPUT);
  pinMode(OE2_138,OUTPUT);
  pinMode(OE3_138,OUTPUT);
  pinMode(OE4_138,OUTPUT);
  
  pinMode(SER,OUTPUT);
  pinMode(CLK,OUTPUT);
  pinMode(RCK,OUTPUT);
  pinMode(OE_595,OUTPUT);
}

#endif
