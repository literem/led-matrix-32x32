#ifndef _COMMAND_H
#define _COMMAND_H

#include "matrix_config.h"

#define CMD_FLAG        0xEE
#define RESULT_FLAG     0xEF
#define CMD_LEN         10

#define GET_CMD_DAT(dat) ((dat[6]<<8) + dat[7])

/****************接收相关命令****************/
#define CMD_ERROR       0x00  //命令错误
#define CMD_GIF         0x01  //播放GIF动画命令


//GIF相关命令
#define GIF_CMD_SPEED   0xE0
#define GIF_CMD_STOP    0xE2

u8 receive_handle_command();
u16 get_command_data();
u8 check_command(u8* buf);

#endif
