#include "matrix32x32.h"
#include "ui_matrix32x32.h"

//一共有32行，每行有32个bit
quint8 buff[32][32];

matrix32x32::matrix32x32(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::matrix32x32)
{
    ui->setupUi(this);

    int i,j;
    for (i = 0; i < 32; i++) {
        for (j = 0; j < 32; j++) {
            buff[i][j]=1;
        }
    }
}

matrix32x32::~matrix32x32()
{
    delete ui;
}

void matrix32x32::paintEvent(QPaintEvent *event)
{
    int i,j;
    int startX,startY;

    QPainter painter(this);
    painter.setBrush(QBrush(QColor(0,0,0)));
    painter.drawRoundedRect(QRect(0,0,485,485),10,10);

    painter.setPen(QColor(255, 0, 0));
    painter.setBrush(QBrush(QColor(255, 0, 0)));
    for(i=0,startY=START_Y;i<32;i++,startY+=PADDING_Y)
    {
        for(j=0,startX=START_X;j<32;j++,startX+=PADDING_X)
        {
            if(buff[i][j] == 0)
            {
                painter.drawEllipse(startX,startY,RADIUS,RADIUS);
            }
        }
    }

    painter.setPen(QColor(198, 198, 198));
    painter.setBrush(QBrush(QColor(198, 198, 198)));
    for(i=0,startY=START_Y;i<32;i++,startY+=PADDING_Y)
    {
        for(j=0,startX=START_X;j<32;j++,startX+=PADDING_X)
        {
            if(buff[i][j] == 1)
            {
                painter.drawEllipse(startX,startY,RADIUS,RADIUS);
            }
        }
    }
}


quint8 *matrix32x32::getBuff()
{
    return (quint8 *)buff;
}

void matrix32x32::createHex(quint8 **result)
{
    quint8 *array = *result;
    int i,j;
    int pos=0;
    for(i=0;i<32;i++)
    {
        for(j=0;j<4;j++,pos++)
        {
            array[pos] = binToHex(i,j*8);
        }
    }
}

quint8 matrix32x32::binToHex(quint8 y, quint8 x)
{
    quint8 m = 128,result = 0;
    for(quint8 k=0;k<8;k++,x++,m>>=1)
    {
        if(buff[y][x]==0) result+=m;
    }
    return result;
}

void matrix32x32::setBuff(int x, int y,quint8 v)
{
    buff[x][y] = v;
}

void matrix32x32::cleanBuff()
{
    int i,j;
    for (i = 0; i < 32; i++) {
        for (j = 0; j < 32; j++) {
            buff[i][j] = 1;
        }
    }
}

void matrix32x32::refresh()
{
    update();
}

void matrix32x32::shiftLeft()
{
    int i,j;
    for(i=0;i<32;i++)
    {
        for(j=1;j<32;j++)
        {
            buff[i][j-1] = buff[i][j];
        }
        buff[i][31] = 0;
    }
    update();
}

void matrix32x32::shiftRight()
{
    int i,j;
    for(i=0;i<32;i++)
    {
        for(j=31;j>0;j--)
        {
            buff[i][j] = buff[i][j-1];
        }
        buff[i][0] = 0;
    }
    update();
}
